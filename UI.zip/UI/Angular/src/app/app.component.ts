import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: '<app-view-ad></app-view-ad>',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'buy-app';
}
