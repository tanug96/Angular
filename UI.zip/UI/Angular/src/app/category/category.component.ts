import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router, NavigationExtras } from '@angular/router';
import { AdService } from '../ad.service';

@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.css']
})
export class CategoryComponent implements OnInit {

  constructor(private route:ActivatedRoute, private adservice:AdService, private router:Router) { }

  info:any=[];
  min:number;
  max:number;
  category:string;
  subcategory:string;
  search:string='';
  ngOnInit() {
    this.route.queryParams.subscribe((params)=>{
     
      this.category=params.category;
      this.subcategory=params.subcategory;
      this.search=params.search;
      if(this.category!=null && this.subcategory== null){
        this.adservice.readAdscat(this.category).subscribe((data)=>{
          this.info=data;
         
      });
    }
      if(this.subcategory!=null){
        this.adservice.readAdssubcat(this.category,this.subcategory).subscribe((data)=>{
          this.info=data;
        });
    }
    if(this.search!=null)
      {
          
          let filter: string = this.search ? this.search.toLocaleLowerCase() : null;
          console.log(filter);
          this.adservice.readSearch(filter).subscribe(data=>{this.info=data;});
        }
    })
    }
    details(ref){
      console.log(ref);
      let navigationextras:NavigationExtras={
        queryParams:ref
      }
      //console.log(navigationextras);
      this.router.navigate(['adDetails'],navigationextras)
    }

    sortByName()
    {
      console.log("Namie sorted");
      this.info.sort((a,b)=>{return a.Title.localeCompare(b.Title)});
    }

    sortByPriceLH()
    {
      console.log("Price sorted");
      this.info.sort((a,b)=>{return a.price - b.price})
    }
    sortByPriceHL()
    {
      console.log("Price sorted");
      this.info.sort((a,b)=>{return b.price - a.price})
    }

    filterByPrice()
    {
      console.log(this.min);
      console.log(this.max);
      this.info=this.info.filter(data=>{
        return data.price>=this.min && data.price<=this.max
            })
    }



}
