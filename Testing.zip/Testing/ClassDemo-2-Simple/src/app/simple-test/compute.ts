export function compute(number) {
  if (number < 0) {
    return 2;
  }

  return number + 1;
}