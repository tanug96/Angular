//var mod=require('./module');
var fr=require('fs');
var app=require('http');
var x=(req,res)=>{
      var x =JSON.parse(fr.readFileSync('hello.js'));
      res.write(JSON.stringify(x));
      res.end();
}

app.createServer(x).listen(1234,()=>{
    console.log("Running");
})
/*function f2(){
    var jsondata='("name":"shiva","age":123)';
    var js = JSON.stringify(jsondata);
    fr.writeFileSync('hello.json',jsondata);
    console.log(JSON.parse(fr.readFileSync('hello.json')))
}
f2();*/