function cuur(){
    console.log("Cuur Service");
}

function payment(msg){
    if(msg<0){
        console.log("UNSUCC")
    }
    else{
        curr();
    }
}