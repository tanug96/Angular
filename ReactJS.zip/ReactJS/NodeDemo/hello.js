var app=require('http');
var mod=require('./module');
var fs=require('fs');
/*app.createServer(       //createServer is an in-built method 

    function(req,res){

        res.writeHead(200,{'Content-Type':'text/html'});
        res.write('<h1>Hello</h1>'+'<input type="text"><br><br>'+'<input type="submit" value="Submit">');
        res.end();
    }


).listen(1234,()=>{
    console.log("Running")
})*/
function f2(){
    console.log(JSON.parse(fs.readFileSync('hello.json')))
};
