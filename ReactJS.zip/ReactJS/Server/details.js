function validate()

{
if((document.regform.fname.value=="")&&(document.regform.lname.value==""))
 {
  document.getElementById('name').innerHTML = "First name or Second name should not be empty";
  return(false);
 }

if(document.regform.prom.value=="")
  {
  document.getElementById('prom').innerHTML = "Promocode field should not be empty";
  return(false);
 }

if(document.regform.age.value=="")
  {
  document.getElementById('age').innerHTML = "Age required";
  return(false);
  }

if(document.regform.email.value=="")
   {
  document.getElementById('email').innerHTML = "Please email";
  return(false);
   }
   
else
   {
   return(true);
   }
}

         
         
        function MyFunction() {
            var count = 0;
            var checkbox = document.getElementsByName("hobbies");
            for(var i=0; i < checkbox.length; i++){
                
               if(checkbox[i].checked){
                    count = count +1;}
        }
        console.log(count);
        var prom=document.getElementById("prom").value;
        var sprom=prom.substring(3,5);
        var num=parseInt(sprom);
        console.log(num);
        if(count<2){
            alert("Select at least two hobbies");
            return false;
        }else if(num%7!=0){
            alert("Last 3 digits of promocode must be divisible by 7");
            return false;
        }
        else if(confirm("Would you like to Submit the form")){
            alert("Form Submitted");
        }
        }
