function data(){
    $.get("data1.json",function(a,b){
        document.getElementById("fname").value=a.fname;
        document.getElementById("lname").value=a.lname;
        document.getElementById("prom").value=a.promo;
        document.getElementById("age").value=a.age;
        document.getElementById("m").value=a.Gender;
        document.getElementById("checkgrp").value=a.hobbies;
        document.getElementById("email").value=a.Email;
    })
}