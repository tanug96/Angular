import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import EmpDetails from './components/empDetails';
import EditDetails from './components/editDetails';

class App extends Component {
  constructor(){
    super();
    this.state={
      employeeDetails:[]
    }
  }
  handleData(newData){
    let empdata = this.state.employeeDetails;
    empdata.push(newData);
    this.setState({
      employeeDetails:empdata
    });
  }
  render() {
    return (
      <div>
        <h2>Employee Details</h2>
        <EmpDetails data={this.state.employeeDetails} onAddData={this.handleData.bind(this)}/>
        <br/>
        <EditDetails showEmpData={this.state.employeeDetails} onUserInput={this.state.onUser}/>
      </div>
    );
  }
}

export default App;
