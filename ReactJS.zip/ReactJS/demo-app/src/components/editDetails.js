import React, { Component } from 'react';


class EditDetails extends Component {
    onChange(){
         this.props.onUserInput(this.refs.TextInput.value);
    }
  render() {
      let details
      details = this.props.showEmpData.map(oneEmp=>{
          return (
          <div>
               Id:<input type="text" value={oneEmp.id} ref="TextInput" onChange={this.state.onChange.bind(this)}/>
               Name:<input type="text" value={oneEmp.name} ref="TextInput" onChange={this.state.onChange.bind(this)}/>
          </div>
          )
      })
    return (
      <div>
       {details}
      </div>
    );
  }
}

export default EditDetails;
