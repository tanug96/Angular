import React, { Component } from 'react';
import EditDetails from './editDetails';

class EmpDetails extends Component {
    constructor(){
        super();
        this.state={
            empData:{}
        }
    }
    handleSubmit(e){
    this.setState({
         empData:{
             id:this.refs.id.value,
             name:this.refs.name.value
         }
     },function(){
            this.props.onAddData(this.state.empData);
        }
     );
     e.preventDefault();
    }
  render() {
    return (
      <div>
        <form onSubmit={this.handleSubmit.bind(this)}>
            <div>
            <label>EmpId:</label>
            <input type="text" ref="id"/><br/><br/>
            <label>EmpName:</label>
            <input type="text" ref="name"/>
            </div>
            <br/>
            <input type="submit" value="Click Me" className="btn btn-success"/>
        </form>
        
      </div>
    );
  }
}

export default EmpDetails;
