import React, { Component } from 'react';
import uuid from 'uuid';
import './addDetails.css';

class AddDetails extends Component{
    constructor(){
    super();
    this.state={
      regData:{}
    }
  }
  handleSubmit(e){
    this.setState({
      regData:{
        id:uuid.v4(),
        Name:this.refs.name.value,
        Email:this.refs.email.value,
        MobNo:this.refs.no.value,
        Address:this.refs.address.value,
        Purpose:this.refs.purpose.value,
        Date:this.refs.date.value,
      }
    },function(){
        //console.log(this.state.regData);
        this.props.onAddData(this.state.regData)
    }
    );
    e.preventDefault();
  }
    render(){
        return(
        <div className="container">
        <form onSubmit={this.handleSubmit.bind(this)}>
         <h2>Customer Registration form</h2>
          <div>
              <label><input type="text" ref="name" placeholder="Username"/></label>
              <br/>
              <label><input type="text" ref="email" placeholder="Email id"/></label>
              <br/>
              <label><input type="text" ref="no" placeholder="Mobile Number"/></label>
              <br/>
              <label><input type="text" ref="address" placeholder="Address"/></label>
              <br/>
              <label><input type="text" ref="purpose" placeholder="Purpose of visit"/></label>
              <br/>
              <label><input type="text" ref="date" placeholder="Date of visit"/></label>
          </div>
              <br/>
              <input type="submit" value="Log in"/>
      </form>
      </div>
        );
    }
}

export default AddDetails;