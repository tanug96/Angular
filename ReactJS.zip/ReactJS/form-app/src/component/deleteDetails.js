import React, { Component } from 'react';
import './deleteDetails.css';

class DeleteDetails extends Component{
    deleteData(id){
    console.log("Data deleted");
    this.props.onDelete(id);
  }
    render(){
        let details = this.props.showFormData.map(newForm=>{
            return (
                
            <div key={newForm.id}><h2>Customer visit Information</h2><table align="center"><tbody><tr><td>Name:</td><td>{newForm.Name}</td></tr><tr><td>Email id:</td><td>{newForm.Email}</td></tr><tr><td>Mobile Number:</td><td>{newForm.MobNo}</td></tr><tr><td>Address:</td><td>{newForm.Address}</td></tr><tr><td>Description/Purpose:</td><td>{newForm.Purpose}</td></tr><tr><td>Date od visit:</td><td>{newForm.Date}</td></tr></tbody></table><input type="button" value="Delete" onClick={this.deleteData.bind(this,this.props.showFormData.id)}/></div>
             )
        })
        return(
            <div align="center">
                
                  {details}
            </div>
        );
    }
}

export default DeleteDetails;