import React, { Component } from 'react';
import AddDetails from './component/addDetails';
import DeleteDetails from './component/deleteDetails';

class App extends Component {
  constructor(){
    super();
    this.state={
      customerDetails:[]
    }
  }
  handleData(newData){
    let formdata = this.state.customerDetails;
    formdata.push(newData);
    this.setState({
      customerDetails:formdata
    });
  }
  handleDeleteData(id){
    let allData = this.state.customerDetails;
    let index = allData.findIndex(oneProject =>
    oneProject.id===id)
    allData.splice(index,1)
     this.setState({ customerDetails:allData })
  }
  render() {
    return (
      <div className="App">
        <AddDetails onAddData={this.handleData.bind(this)}></AddDetails><br/>
        <DeleteDetails showFormData={this.state.customerDetails} onDelete={this.handleDeleteData.bind(this)}></DeleteDetails>
      </div>
    );
  }
}

export default App;
