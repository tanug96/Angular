var exp = require('express')
var parser = require('body-parser')
var app = exp();
var fs = require('fs');
var cors = require('cors');
var MongoClient = require('mongodb').MongoClient;
//var mod = require('./module');


/*app.get('/rest/api/readbyid',(req,res)=>{
    res.header("Access-Control-Allow-Origin","*");
    res.header("Access-Control-Allow-Headers","Origin,X-Requested-With,Content-Type,Accept");
    res.send(JSON.parse(fs.readFileSync('hello.json')));
});*/

app.get('/rest/api/readbyid',(req,res)=>{
    res.header("Access-Control-Allow-Origin","*");
    res.header("Access-Control-Allow-Headers","Origin,X-Requested-With,Content-Type,Accept");
    
    MongoClient.connect("mongodb://localhost:27017/emp",function(err,dbvar){
    if(err) throw err;
    var col1 = dbvar.db('emp');
    col1.collection('emp').find({}).toArray(function(err,result){
        if(err) throw err;
        else{
        //console.log(result);
        res.send(result);
        //console.log(result);
        }
        dbvar.close();
    });
});
});


app.use(parser.json());

app.post('/rest/api',(req,res)=>{
    res.header("Access-Control-Allow-Origin","*");
    res.header("Access-Control-Allow-Headers","Origin,X-Requested-With,Content-Type,Accept"); 
    res.send(req.body);
    //console.log(req.body);
MongoClient.connect("mongodb://localhost:27017/emp",
function(err,dbvar){
    if(err) throw err
    var col1 = dbvar.db('emp');
    col1.collection('emp').insert(req.body,true,function(err,res){
    //col1.collection('emp').findOne({},function(err,result){
        //col1.collection('emp').find({}).toArray(function(err,result){
        if(err) throw err;
        console.log("result");
        dbvar.close();
    });
    dbvar.close();
});
});

app.delete('/rest/api/del',(req,res)=>{
    res.header("Access-Control-Allow-Origin","*");
    res.header("Access-Control-Allow-Headers","Origin,X-Requested-With,Content-Type,Accept"); 
    res.send(req.body);
    console.log(req.body);
    MongoClient.connect("mongodb://localhost:27017/emp", function(err, dbvar) {
  if (err) throw err;
  var col1 = dbvar.db("emp");
  col1.collection("emp").deleteOne(req.body,true,function(err, res) {
    if (err) throw err;
    console.log("1 document deleted");
    dbvar.close();
  });
dbvar.close()
})
    });

/*app.put('/rest/api/updt',(req,res)=>{
    res.header("Access-Control-Allow-Origin","*");
    res.header("Access-Control-Allow-Headers","Origin,X-Requested-With,Content-Type,Accept"); 
    res.send(req.body);
    console.log(req.body);
    MongoClient.connect("mongodb://localhost:27017/emp", function(err, dbvar) {
  if (err) throw err;
  var col1 = dbvar.db("emp");
  col1.collection("emp").updateOne(req.body,true,function(err, res) {
    if (err) throw err;
    console.log("1 document updated");
    dbvar.close();
  });
dbvar.close()
})
    });*/

app.use(cors()).listen(1234,()=>{
    console.log("Express Started");
})

