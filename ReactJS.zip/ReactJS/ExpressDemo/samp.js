var exp = require('express');
var app = exp();

app.set("view engine","jade");

app.get('/jaderequest',(req,res)=>{
    res.render('file1');
}).listen(2020,()=>{
    console.log("Hello");
})