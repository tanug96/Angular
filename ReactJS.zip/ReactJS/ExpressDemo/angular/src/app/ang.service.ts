import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable,of} from 'rxjs'

@Injectable({
  providedIn: 'root'
})
export class AngService {

  constructor(private http:HttpClient) { }
  
  getAllEmp():Observable<any>{
    return this.http.get('http://localhost:1234/rest/api/readbyid')
  }
  getInfo(data):Observable<any>{
    //console.log(data);
    return this.http.post('http://localhost:1234/rest/api',{id:data[0], name:data[1]})
  }

  deleteInfo(dele):Observable<any>{
    alert(dele);
    return this.http.delete('http://localhost:1234/rest/api/del',JSON.stringify(dele));
  }

  updateData(upd):Observable<any>{
    return this.http.put('http://localhost:1234/rest/api/updt',JSON.stringify(upd));
  }

}
