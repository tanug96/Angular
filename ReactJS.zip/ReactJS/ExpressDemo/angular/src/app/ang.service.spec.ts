import { TestBed, inject } from '@angular/core/testing';

import { AngService } from './ang.service';

describe('AngService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AngService]
    });
  });

  it('should be created', inject([AngService], (service: AngService) => {
    expect(service).toBeTruthy();
  }));
});
