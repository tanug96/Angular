import { Component,OnInit } from '@angular/core';
import {AngService} from './ang.service';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'angular';
  data:any;
  id:number;
  name:string;
  postData:any;
  info:any[]=[];
constructor(private call:AngService){}
ngOnInit(){
  //console.log("Component");
   //this.call.getAllEmp().subscribe(data=>{this.data=data});
  // this.data.getInfo(this.postData).subscribe();


}
showData(){
  this.call.getAllEmp().subscribe(data=>{this.data=data;console.log(this.data);});
  
}
showInfo(){
  this.info.push(this.id,this.name)
  this.call.getInfo(this.info).subscribe();
  //console.log(this.info);
}

deleteData(r){
  console.log(r);
  this.call.deleteInfo(r).subscribe();
}

updateData(){
  
}
}