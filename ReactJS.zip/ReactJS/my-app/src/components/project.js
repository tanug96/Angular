import React, { Component } from 'react';
import ProjectItem from './projectItem';
import PropTypes from 'prop-types';

class Projects extends Component {

  deleteProject(id){
    this.props.onDelete(id);
  }
  render() {
      let projectItems;
      projectItems = this.props.Projects.map(
          oneProject => {
              return(
                  <ProjectItem key={oneProject.title} project={oneProject} onDelete={this.deleteProject.bind(this)}/>
              )
          }
      );
    return (
      <div>
        {console.log(projectItems)}
        {projectItems}
        
      </div>
    );
  }
}

Projects.propTypes =
{
  Projects: PropTypes.array,
  onDelete: PropTypes.func
}
export default Projects;
