import React, { Component } from 'react'; 

class Todos extends Component {
  render() {
      let showtodos;
   
       showtodos = this.props.todosData.map(
          oneproj => {
              return (
                  <div>
                  <p>{oneproj.userId}</p>
                  <p>{oneproj.id}</p>
                  <p>{oneproj.title}</p>
                  <p>{oneproj.completed}</p>
                  </div>
                  );
          }
      );
    return (
      <div>
          {showtodos}
      </div>
    );
  }
}

export default Todos;