import React, { Component } from 'react';
import './App.css';
import Projects from './components/project';
import AddProject from './components/AddProject';
import uuid from 'uuid';
import $ from 'jquery';
import Todos from './components/Todos';

class App extends Component {

  constructor(){
    super();
    this.state={
      projectsfromApp:[],
      todos:[]
    }

  }

  handleDeleteProject(id){
    let allProjects = this.state.projectsfromApp;

    let index = allProjects.findIndex(oneProject =>
    oneProject.id===id)
    allProjects.splice(index,1)
     this.setState({ projectsfromApp:allProjects })
  }

  handleAddProject(newProj){
   // alert("data submitted to app");
    //console.log("data submitted to app "+newProj);

    let projects = this.state.projectsfromApp;
    projects.push(newProj)
    this.setState({projectsfromApp:projects});
  }

  componentWillMount(){
    console.log("componentWillMount");
    this.setState({
      projectsfromApp:[
        {
          id: uuid.v4(),//generate universally unique id
          title: 'Business Website',
          category:'Web design'
        },
        {
          id: uuid.v4(),
          title: 'Social App',
          category:'Mobile development'
        },
        {
          id: uuid.v4(),
          title: 'Ecommerce Shopping',
          category:'Web development'
        }
      ]
  });
    }
  
  componentDidMount(){
    this.getTodos();
  }

  getTodos(){
    $.ajax({
      url:"http://jsonplaceholder.typicode.com/todos",
      datatype:'json',
      cache:false,
      success:function(data){
        this.setState({ todos:data }, function(){
          console.log("Downloaded Todos:==========\n");
          console.log(data);
          
        });
      }.bind(this)
    });
  }

  render() {
    return (
      <div>
        <AddProject onAddProject={this.handleAddProject.bind(this)}/>
        <Projects Projects={this.state.projectsfromApp} test="Hello World" onDelete={this.handleDeleteProject.bind(this)}/> 
        <Todos todosData={this.state.todos}/>
      </div>
    );
  }
}


export default App;
