import React, { Component } from 'react';
import Login from './components/login';
import Home from './components/home';
import {BrowserRouter as Router,Switch,Route,Link } from 'react-router-dom';


class AppRoute extends Component {
    render(){
        return(
            <Router>
                <div>
                    <ul>
                        <li> <Link to={'/'}> Home </Link></li>
                        <li> <Link to={'/Login'}> Login </Link></li>
                    </ul>
                    <hr/>
                    <Switch>
                        <Route exact path='/' component={Home}/>
                        <Route exact path='/Login' component={Login}/>
                    </Switch>
                </div>
    </Router>
        );
    }
    
}


export default AppRoute;