import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
//import AppRoute from './App-Route';
import registerServiceWorker from './registerServiceWorker';

ReactDOM.render(<App />, document.getElementById('root'));
//ReactDOM.render(<AppRoute />, document.getElementById('root'));
registerServiceWorker();
