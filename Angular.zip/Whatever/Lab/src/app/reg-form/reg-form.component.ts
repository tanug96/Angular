import { Component, OnInit } from '@angular/core';
import { FormControl, Validators,FormGroup} from '@angular/forms';


@Component({
  selector: 'app-reg-form',
  templateUrl: './reg-form.component.html',
  styleUrls: ['./reg-form.component.css']
})
export class RegFormComponent implements OnInit {
  regForm=new FormGroup({
    id: new FormControl('',Validators.required),
    name: new FormControl('',Validators.required),
    cost: new FormControl('',Validators.required),
    online: new FormControl('',Validators.required),
    cat: new FormControl('',Validators.required),
    store: new FormControl('',Validators.requiredTrue)
  });

  constructor() { }

  ngOnInit() {
  }

  showProd(){
    console.log("Hello");
  }
  get id() { return this.regForm.get('id'); }

}
