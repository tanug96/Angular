import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class EmpService {

  constructor(private http:HttpClient) { }
  empData = '/assets/emp.json';
  getData():Observable<any>{
    return this.http.get(this.empData);
  }
}
