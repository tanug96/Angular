import { Component } from '@angular/core';
import{TimePeriodComponent} from './time-period/time-period.component'

@Component({
  selector: 'app-root',
  template: '<app-time-period>',
  styleUrls: ['./app.component.css'],
  
})
export class AppComponent {
  title = 'insurance';
}


