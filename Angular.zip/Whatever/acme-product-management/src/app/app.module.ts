import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { CarModelComponent } from './car-model/car-model.component';

@NgModule({
  declarations: [
    AppComponent,
    CarModelComponent
  ],
  imports: [
    BrowserModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent,CarModelComponent]
})
export class AppModule { }
