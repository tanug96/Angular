import { Component, OnInit } from '@angular/core';

declare var $:any;
@Component({
  selector: 'app-time-period',
  templateUrl: './time-period.component.html',
  styleUrls: ['./time-period.component.css']
})




export class TimePeriodComponent implements OnInit {

  constructor() { }
listFilter:string;
  ngOnInit() {
     $.get('src/app/time-period/1.json',(d,r:any)=>{
        this.select=d.a;
        this.one=d.q;
        this.two=d.w;
        this.three=d.e;
        this.four=d.t;
    })
  }
select:string;
one:string;
two:string;
three:string;
four:string;

valu="rahyl";


jd(qw:string):void{
   this.valu = qw;
   
}
calculate():void{
  
  alert (this.listFilter)
}
}


//}
//}




//export class candidateData implements OnInit{
  //   ngOnInit(){
        
   // } 


//candidateq(i):void{
  //  $.get('app/candidate/'+i+'.json',(d,r:any)=>{
    //    this.candidateName=d.candidateName;
      //  this.candidateId=d.candidateid;
        //this.candidateAge=d.candidateAge;
       // this.candidateCompany=d.candidateCompany;
    //})
//}
