import { Injectable } from '@angular/core';
//import {MODELS} from './models';
import { Observable, of } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
export class ModelService {
  
  constructor(private http:HttpClient) {}
  getModels(): Observable<any[]> {
  return this.http.get('/api/model');
}
  getTime(): Observable<any[]>  {
  return this.http.get('/api/time');
  }
}