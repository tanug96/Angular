import { Component,OnInit} from '@angular/core';
declare var $: any;
import {ModelService} from './car-model.service';

@Component({
  selector: 'app-car-model',
  templateUrl: './car-model.component.html',
  styleUrls: ['./car-model.component.css']
})

export class CarModelComponent {
  title:string="Car Models";
  models:any[];
  period:any[];
  constructor(private modelService:ModelService){ }
  getModels():void{
    this.modelService.getModels().subscribe(models=>this.models=models);
  }
  getTime():void{
    this.modelService.getTime().subscribe(period=>this.period=period); 
  }
  ngOnInit(){
    this.getModels();
    //this.getTime();
  }
  int:string;
  call1(ins:string){
    this.int=ins;
    //alert(this.int);
  }
  call2(){
    if(this.int=this.models[1]){
      alert("congrats");
      this.getTime();

    }
  }
  
  }


  

