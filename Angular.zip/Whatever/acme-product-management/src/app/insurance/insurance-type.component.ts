import { Component, OnInit } from '@angular/core';
import{LoginService} from '../login.service';
@Component({
  selector: 'app-insurance-type',
  templateUrl: './insurance-type.component.html',
  styleUrls: ['./insurance-type.component.css']
})
export class InsuranceTypeComponent implements OnInit {

 
selectedradio:string;
  constructor(private _productService:LoginService){}
  heading:string="";
  detail:string[]=[];
  answer:string[]=[];
  head:string;
  option:string[];
  select:any;
  headtemp:number=0;
  
  ngOnInit():void{
        //this._productService.getProducts('api/products/insurance.json').subscribe(products=>this.head=products[0].head);
        //this._productService.getProducts('api/products/insurance.json').subscribe(products=>this.option=products[0].options);      
        this._productService.getfile('/assets/insuranceType.json').subscribe(data=>{
        this.head=data[0].head});
        //console.log(this.data);
        this._productService.getfile('/assets/insuranceType.json').subscribe(data=>{
        this.option=data[0].options});
}
 
  insu:string;
  xyz(temp:string)
  {
    this.insu= temp;
  }

  page3()
  {
    
    this.detail.push(this.insu);
    console.log(this.detail);
    if(this.detail.length<3)
    {
    //this._productService.getProducts(`api/products/${this.insu}.json`).subscribe(products=>this.head=products[0].head);
    //this._productService.getProducts(`api/products/${this.insu}.json`).subscribe(products=>this.option=products[0].options);
    this._productService.getfile(`/assets/${this.insu}.json`).subscribe(products=>{this.head=products[0].head});
    this._productService.getfile(`/assets/${this.insu}.json`).subscribe(products=>{this.option=products[0].options});
  }
  else
  {
    this.head="Insurance Detail";
  }
  


}
}


