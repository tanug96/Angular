import { Component, OnInit } from '@angular/core';
import {MobileService} from '../mobile.service'

@Component({
  selector: 'app-mobile-info',
  templateUrl: './mobile-info.component.html',
  styleUrls: ['./mobile-info.component.css']
})
export class MobileInfoComponent implements OnInit {

  data:any;
  constructor(private mobileService:MobileService) { }

  ngOnInit() {
    this.mobileService.getInfo().subscribe(data=>{this.data=data;console.log(this.data);
    })
  }
//delete the row of respective id(index)
  delete(id){
    this.data.splice(id,1);
  }
// sort id in ascending order
  sortId(){
    this.data.sort(function(a,b){
      return(''+a.mobId).localeCompare(b.mobId);
    })
  }
//sort name in ascending order
  sortName(){
    this.data.sort(function(a,b){
      return(''+a.mobName).localeCompare(b.mobName);
    })
  }
//sort price in ascending order
  sortPrice(){
    this.data.sort(function(a,b){
      return(''+b.mobPrice).localeCompare(a.mobPrice);
    })
  }

}
