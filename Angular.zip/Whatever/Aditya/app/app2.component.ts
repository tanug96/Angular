import { Component } from 'angular2/core';
import {EmpDataComponent} from './employees/employee-data.component';

 
 @Component({
     selector: 'pm-app',
     template: `<pm-data></pm-data>`,
     directives:[EmpDataComponent]
 })

  export class App2Component{

 }