System.register(['angular2/core'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1;
    var EmpDataComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            }],
        execute: function() {
            EmpDataComponent = (function () {
                function EmpDataComponent() {
                    this.pageTitle = "Employees Data";
                }
                EmpDataComponent.prototype.emp1 = function () {
                    var _this = this;
                    $.get('Emp1.component.json', function (d, r) {
                        _this.EmpId = d.Id;
                        _this.EmpFName = d.FN;
                        _this.EmpLName = d.LN;
                        _this.EmpCode = d.Code;
                    });
                };
                EmpDataComponent.prototype.emp2 = function () {
                    var _this = this;
                    $.get('Emp2.component.json', function (d, r) {
                        _this.EmpId = d.Id;
                        _this.EmpFName = d.FN;
                        _this.EmpLName = d.LN;
                        _this.EmpCode = d.Code;
                    });
                };
                EmpDataComponent.prototype.emp3 = function () {
                    var _this = this;
                    $.get('Emp3.component.json', function (d, r) {
                        _this.EmpId = d.Id;
                        _this.EmpFName = d.FN;
                        _this.EmpLName = d.LN;
                        _this.EmpCode = d.Code;
                    });
                };
                EmpDataComponent.prototype.emp4 = function () {
                    var _this = this;
                    $.get('Emp4.component.json', function (d, r) {
                        _this.EmpId = d.Id;
                        _this.EmpFName = d.FN;
                        _this.EmpLName = d.LN;
                        _this.EmpCode = d.Code;
                    });
                };
                EmpDataComponent = __decorate([
                    core_1.Component({
                        selector: 'pm-app',
                        templateUrl: 'app/employees/employee-data.component.html'
                    }), 
                    __metadata('design:paramtypes', [])
                ], EmpDataComponent);
                return EmpDataComponent;
            }());
            exports_1("EmpDataComponent", EmpDataComponent);
        }
    }
});
/*emp1():void{
    
    this.EmpId= 245837,
    this.EmpFName= "Nick",
    this.EmpLName= "Jonas",
    this.EmpCode= "Jon-0023"
}
emp2():void{
    
    this.EmpId= 245378,
    this.EmpFName= "Justin",
    this.EmpLName= "Foley",
    this.EmpCode=  "Jus-0024"
}
emp3():void{
    
    this.EmpId= 245645,
    this.EmpFName= "Finch",
    this.EmpLName= "Janson",
    this.EmpCode=  "Fin-0025"
}
emp4():void{
    
    this.EmpId=245234,
   this.EmpFName= "Sherry",
    this.EmpLName="Royce",
    this.EmpCode=  "She-0026"
}*/
//# sourceMappingURL=employee-data.component.js.map