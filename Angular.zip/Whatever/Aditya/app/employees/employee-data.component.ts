import { Component } from 'angular2/core';
declare var $: any;

@Component({
    selector:'pm-app',
    templateUrl:'app/employees/employee-data.component.html'
})

export class EmpDataComponent{
    pageTitle:string="Employees Data";
    EmpId:number;
    EmpFName:string;
    EmpLName:string;
    EmpCode:any;
    emp1(){
        $.get('Emp1.component.json',(d,r)=>{
            this.EmpId=d.Id;
            this.EmpFName=d.FN;
            this.EmpLName=d.LN;
            this.EmpCode=d.Code;
        })
    }
    emp2(){
        $.get('Emp2.component.json',(d,r)=>{
            this.EmpId=d.Id;
            this.EmpFName=d.FN;
            this.EmpLName=d.LN;
            this.EmpCode=d.Code;
        })
    }
    emp3(){
        $.get('Emp3.component.json',(d,r)=>{
            this.EmpId=d.Id;
            this.EmpFName=d.FN;
            this.EmpLName=d.LN;
            this.EmpCode=d.Code;
        })}
    emp4(){
        $.get('Emp4.component.json',(d,r)=>{
            this.EmpId=d.Id;
            this.EmpFName=d.FN;
            this.EmpLName=d.LN;
            this.EmpCode=d.Code;
        })}
    }
        /*emp1():void{
            
            this.EmpId= 245837,
            this.EmpFName= "Nick",
            this.EmpLName= "Jonas",
            this.EmpCode= "Jon-0023"
        }
        emp2():void{
            
            this.EmpId= 245378,
            this.EmpFName= "Justin",
            this.EmpLName= "Foley",
            this.EmpCode=  "Jus-0024"
        }
        emp3():void{
            
            this.EmpId= 245645,
            this.EmpFName= "Finch",
            this.EmpLName= "Janson",
            this.EmpCode=  "Fin-0025"
        }
        emp4():void{
            
            this.EmpId=245234,
           this.EmpFName= "Sherry",
            this.EmpLName="Royce",
            this.EmpCode=  "She-0026"
        }*/
        