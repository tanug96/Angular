
import { AppComponent }  from './app.component';
import { ProductListComponent } from './products/product-list.component';
import { EmpDataComponent } from './employees/employee-data.component';
import { Router } from 'angular2/router';
import { APPLICATION_COMMON_PROVIDERS }  from 'angular2/core';

const appRoutes: Routes = [
   { path: 'app/products/product-list.component.html', component: ProductListComponent },
   { path: 'app/employees/employee-data.component.html', component: EmpDataComponent },
];

@NgModule ({
   imports: [ BrowserModule,
   RouterModule.forRoot(appRoutes)],
   declarations: [ AppComponent,ProductListComponent,EmpDataComponent]
})
export class AppModule { }