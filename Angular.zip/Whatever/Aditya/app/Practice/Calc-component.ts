import { Component } from 'angular2/core';

@Component({
    selector:'calc',
    templateUrl:'app/practice/calc.component'
})

export class CalcComponent{
        
}