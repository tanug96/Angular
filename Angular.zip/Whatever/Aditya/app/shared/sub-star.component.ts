import { Component, OnChanges, Input,Output, EventEmitter } from 'angular2/core';

@Component({
    selector: 'ai-substar',
    templateUrl: 'app/shared/sub-star.component.html',
    styleUrls: ['app/shared/sub-star.component.css']
})

export class SubStarComponent {
    @Input() productName: string;

}                 