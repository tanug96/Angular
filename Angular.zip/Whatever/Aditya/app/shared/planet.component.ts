import { Component, OnChanges, Input,Output, EventEmitter } from 'angular2/core';
import { IProduct } from '../products/product';
 
@Component({
    selector: 'ai-planet',
    templateUrl: 'app/shared/planet.component.html',
    styleUrls: ['app/shared/planet.component.css']
})
export class PlanetComponent implements OnChanges {
    @Input() rating: number;
    @Input() product: IProduct;
    starWidth: number;
    @Output() ratingClicked: EventEmitter<string> =
    new EventEmitter<string>();
 
    ngOnChanges(): void {
        this.starWidth = this.rating * 86 / 5;
    }
    onClick() {
        this.ratingClicked.emit(`The rating ${this.rating} was clicked!`);
        //alert("Hello World");
    }
}                                                                   