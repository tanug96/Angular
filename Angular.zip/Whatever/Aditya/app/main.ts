import { bootstrap } from 'angular2/platform/browser';

// Our main component
import { AppComponent } from './app.component';
//import { App2Component } from './app2.component';

bootstrap(AppComponent);
//bootstrap(App2Component);