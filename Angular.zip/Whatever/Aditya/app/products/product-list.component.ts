import { Component,OnInit } from 'angular2/core';
import {IProduct} from './product';
import {ProductFilterPipe} from './product-filter.pipe';
import {StarComponent} from '../shared/star.component';
import {PlanetComponent} from '../shared/planet.component';
import {ProductService} from './product.service';

@Component({
    selector: 'pm-products',
    templateUrl:'app/products/product-list.component.html',
    styleUrls:['app/products/product-list.component.css'],
    pipes: [ProductFilterPipe],
    directives:[StarComponent,PlanetComponent]
})

export class ProductListComponent implements OnInit{

    ngOnInit():void{
        alert("Welcome!");
         this._productService.getProducts()
            .subscribe(products=>this.products=products,error=>this.errorMessage=error);
    }
    OnRatingClicked(message:string):void{
        alert("Rating was clicked"+message);
    }
    listFilter:string='';
    imageWidth:number=80;
    imageMargin:number=20;
    pageTitle:string="Product List";
    showImage:boolean=true;
    errorMessage:string;
    toggleImages():void{
        this.showImage= !this.showImage;
    }
        products: IProduct[];
        constructor(private _productService:ProductService)
        { 
        }

    
}

