import { Component, OnInit } from '@angular/core';
import {QuizService} from '../quiz.service';

@Component({
  selector: 'app-ques',
  templateUrl: './ques.component.html',
  styleUrls: ['./ques.component.css']
})
export class QuesComponent implements OnInit {
  top="Quiz";
  id:number;
  ques:any[];
  name:string;
  options:any[];
  optionarray:any[];
  arr1:any[];
  arr2:any[];
  ansUser:string[]=[];
  quesIndex:number=0;
  ansArray:any=[];
  correct:number=0;
  constructor(private quizService:QuizService) { }

  getQues():void{
    this.quizService.getQues().subscribe(ques=>{this.ques=ques;console.log(this.ques)});
  }
  ngOnInit() {
    this.getQues();
  }
  printques(l:number){
    //for(l=0;l<this.ques.length;l++){
    document.getElementById("show").innerHTML=this.ques[l].name;
    this.optionarray=this.ques[l].options;
    this.quesIndex=l;
   // }
  }
  checkans(ty:string){
    this.ansUser[this.quesIndex]=ty;
    console.log(this.ansUser);
  }
  submitAns(){
    for(let i=0;i<this.ques.length;i++){
      this.ansArray.push(this.ques[i].answer)
    }
    for(let b=0;b<this.ansUser.length;b++){
      if(this.ansUser[b]==this.ansArray[b]){
        this.correct++;
        console.log(this.correct);
      }
    }
    alert("Your score is "+this.correct);
  }

}
