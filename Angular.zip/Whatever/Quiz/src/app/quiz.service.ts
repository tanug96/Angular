import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class QuizService {

  constructor(private http:HttpClient) { }
  loginUrl='/assets/login.json'
  getlogin():Observable<any[]>{
    return this.http.get(this.loginUrl);
  }
  quesUrl='/assets/questions.json';
  getQues():Observable<any[]>{
     return this.http.get(this.quesUrl);
  }
}

