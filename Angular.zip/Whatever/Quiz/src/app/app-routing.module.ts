import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {LoginComponent} from './login/login.component';
import {RulesComponent} from './rules/rules.component';
import {QuesComponent} from './ques/ques.component';

const routes:Routes=[
  {path:'login',component: LoginComponent },
  {path:'rules',component: RulesComponent },
  {path:'ques',component: QuesComponent}
];

@NgModule({
  exports:[RouterModule],
  imports:[RouterModule.forRoot(routes)]
})
export class AppRoutingModule { }
