import { Component, OnInit } from '@angular/core';
import {QuizService} from '../quiz.service';



@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
   id:number;
   password:number;
   data:any;
  constructor(private quizService:QuizService) { }
  getlogin():void{
    this.quizService.getlogin()
    .subscribe(data => {
      this.data = data;
      console.log(this.data)
    });
  }
  ngOnInit() {
    this.getlogin();
  }
  login(){
    for(var i=0;i<this.data.length;i++)
    {
      if(this.id==this.data[i].id&&this.password==this.data[i].password){
        alert("You have successfully logged in");
        break;
      }
      else{
        alert("Invalid credentials.");
      }
    }
  }
}
