function validate()

{
if((document.regform.fname.value=="")&&(document.regform.lname.value==""))
 {
  document.getElementById('une').innerHTML = "First name or Second name should not be empty";
  return(false);
 }

if(document.regform.prom.value=="")
  {
  document.getElementById('prom').innerHTML = "Promocode field should not be empty";
  return(false);
 }

if(document.regform.age.value=="")
  {
  document.getElementById('age').innerHTML = "Age required";
  return(false);
  }

if(document.regform.email.value=="")
   {
  document.getElementById('email').innerHTML = "Please email";
  return(false);
   }
   
else
   {
   return(true);
   }
}
