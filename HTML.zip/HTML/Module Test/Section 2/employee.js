var empId,empName,empSalary,empDesignation;
var quan = new Set();

class Employee{
    constructor(empId,empName,empSalary,empDesignation){
        this.empId=empId;
        this.empName=empName;
        this.empSalary=empSalary;
        this.empDesignation=empDesignation;
    }
}

var obj1 = new Employee(1002,"Vikash",9812,"Consultant");
var obj2 = new Employee(1003,"Amresh",6661,"Sr Consultant");
var obj3 = new Employee(1001,"Uma",10000,"Sr Manager");
var obj4 = new Employee(1000,"Vaishali",9123,"Manager");

// a.
quan.add(obj1);
quan.add(obj2);
quan.add(obj3);
quan.add(obj4);

// b.
var arr = Array.from(quan);
var arr1 = arr.sort(function(a,b){return a.empId - b.empId;});
var quansort = new Set(arr1);
console.log(quansort);

// c.
del = function(){
    for(obj of quan){
        if(empId==' ')
          quan.delete(obj);
        }

// d.(_proto_)
class Login{
    constructor(){
        Login.prototype.getLogin=function(){
        console.log()
        }
        Login.prototype.getLogOut=function(){

        }
    }
}


