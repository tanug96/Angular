/*function getData(){
    var xhttp=new XMLHttpRequest();
    console.log(xhttp);
    xhttp.open("GET","demo.txt",true);
    xhttp.onreadystatechange=function(){
        if(this.readyState==4&& this.status==200){
            alert(this.responseText);
        }
    };
    xhttp.send();
}*/
