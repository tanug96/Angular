function getmodules(){
    var dom = document.getElementById("domain").value;
    if(dom=="JEE"){
        document.getElementById("module").innerHTML = "<option>Core Java</option><option>Servlet-JSP</option><option>Spring</option>";
    }
    if(dom==".NET"){
        document.getElementById("module").innerHTML = "<option>C#</option><option>ADO.NET</option><option>ASP.NET</option>";
    }
}
function sum(){
    var mpt = document.getElementById("a").value;
    var mtt = document.getElementById("b").value;
    var assign = document.getElementById("c").value;
    var total;
    total = parseInt(mpt)+parseInt(mtt)+parseInt(assign);
    alert("Module Score is "+total);
}