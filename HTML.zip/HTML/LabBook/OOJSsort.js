var arrayProduct=[];
var Products = function(id,name,price){//parameters that are being passed
    this.prodId=id;//prodId is attribute
    this.prodName=name;
    this.prodPrice=price;
}; 
satAllData=function(prod){
    arrayProduct.push(prod);
}
sortByPrice=function(onepro,twopro){
    if(onepro.prodPrice>twopro.prodPrice) return 1;
    if(onepro.prodPrice===twopro.prodPrice) return -1;
    return 0;
}
displayAllProducts=function(){
    for(var i=0;i<arrayProduct.length;i++){
        console.log("Product Id is "+arrayProduct[i].prodId);
        console.log("Product Name is "+arrayProduct[i].prodName);
        console.log("Product Price is "+arrayProduct[i].prodPrice);
    }
}
var prodOne=new Products(1001,"TV",10000);  
var prodTwo=new Products(1002,"CD",1000);
var prodThree=new Products(1003,"ROBO",5000);

deleteAll=function(id){
    var index = arrayProduct.indexOf(id);
        arrayProduct.splice(index,1);
}

satAllData(prodOne);
satAllData(prodTwo);
satAllData(prodThree);
this.arrayProduct=this.arrayProduct.sort(this.sortByPrice)
deleteAll(1002);
displayAllProducts();