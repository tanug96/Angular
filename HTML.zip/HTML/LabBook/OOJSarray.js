var arrayProduct=[];
var Products = function(id,name,price){//parameters that are being passed
    this.prodId=id;//prodId is attribute
    this.prodName=name;
    this.prodPrice=price;
}; 
satAllData=function(prod){
    arrayProduct.push(prod);
}
displayAllProducts=function(){
    for(var i=0;i<arrayProduct.length;i++){
        console.log("Product Id is "+arrayProduct[i].prodId);
        console.log("Product Name is "+arrayProduct[i].prodName);
        console.log("Product Price is "+arrayProduct[i].prodPrice);
    }
}
var prodOne=new Products(1001,"TV",10000);  
var prodTwo=new Products(1002,"CD",1000);
var prodThree=new Products(1003,"ROBO",5000);
var sortData=function(){
    for(var i=0;i<arrayProduct.lengt;i++){
    if(arrayProduct[i]<arrayProduct[i+1])
        console.log("Product Id is "+arrayProduct[i].prodId);
    else 
    console.log("Product Id is "+arrayProduct[i+1].prodId);
    }
}
satAllData(prodOne);
satAllData(prodTwo);
satAllData(prodThree);

displayAllProducts()