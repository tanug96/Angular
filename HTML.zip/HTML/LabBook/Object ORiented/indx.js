var i=0;
var prodId,prodName,prodPrice;
var arr=[];
var Product = function(id,name,price){
    this.prodId=id;
    this.prodName=name;
    this.prodPrice=price;
}
function myFunction(){
    var id=document.getElementById("a").value;
    var name=document.getElementById("b").value;
    var price=document.getElementById("c").value;
    var obj = new Product(id,name,price);
    arr.push(obj);
    document.getElementById("show").innerHTML+="<tr><td>Id:"+arr[i].prodId+"</td><td>Name:"+arr[i].prodName+"</td><td>Price:"+arr[i].prodPrice+"</td><td><input type='button' value='Delete' onclick='del(this)' class='btn btn-danger'></td><td><input type='button' value='Update' onclick='updt(this)' class='btn btn-info'></td></tr>";
    i++;
}
function del(row){
    x = row.parentNode.parentNode.rowIndex;
    arr.splice(x,1);
    document.getElementById("show").deleteRow(x);
    i--;
}
function updt(row){
    document.getElementById("newtab").innerHTML="<table class='table table-bordered table-striped table-responsive table-hover'><tr><td>Id:</td><td><input type='text' id='updateid'</td></tr><tr><td>Name:</td><td><input type='text' id='updatename'</td></tr><tr><td>Price:</td><td><input type='text' id='updateprice'</td></tr></table><input type='button' value='Update' onclick='upd()' class='btn btn-success'>";
    k = row.parentNode.parentNode.rowIndex;
    document.getElementById("updateid").value=arr[k].prodId;
    document.getElementById("updatename").value=arr[k].prodName;
    document.getElementById("updateprice").value=arr[k].prodPrice;
}
function upd(){
    var newid = document.getElementById("updateid").value;
    var newname = document.getElementById("updatename").value;
    var newprice = document.getElementById("updateprice").value;
    arr[k].prodId=newid;
    arr[k].prodName=newname;
    arr[k].prodPrice=newprice;
    var newtable = document.getElementById("show"); 
    newtable.rows[k].cells[0].innerHTML="Id:"+newid;
    newtable.rows[k].cells[1].innerHTML="Name:"+newname;
    newtable.rows[k].cells[2].innerHTML="Price:"+newprice;
    

}
