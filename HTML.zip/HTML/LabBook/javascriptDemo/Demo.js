var anotherwindow;
function getdata(){
    anotherwindow=window.open("","","height=400,width=300");
    var Id=document.getElementById("eid").value
    anotherwindow.document.write("Id "+" "+Id);
    var name=document.getElementById("ename").value
    anotherwindow.document.write("Name "+" "+name);
    var sal=document.getElementById("esal").value
    var salary =parseInt(sal);
    var total =salary+(salary*0.12)+1000;
    anotherwindow.document.write("Total salary is"+" "+total);

}