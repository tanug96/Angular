 function disploop(){
 for(var i=0;i<100;i++){
    document.write("<p><table><tr><td>"+i+"</td><td>"+(i+1)+"</td><td>"+(i+2)+"</td><td>"+(i+3)+"</td><td>"+(i+4)+"</td<td>"+(i+5)+"</td> <td>"+(i+6)+"</td><td>"+(i+7)+"</td><td>"+(i+8)+"</td><td>"+(i+9)+"</td></tr></table></p>");
    i=(i+9);
}
document.write(i);
}