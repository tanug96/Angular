var prodId,prodname,prodPrice;
var Products = function(id,name,price){//parameters that are being passed
    this.prodId=id;//prodId is attribute
    this.prodName=name;
    this.prodPrice=price;
    this.getData=function(){
        console.log("Id is "+this.prodId);//or("Id is"+id)
    }
}; 

var prodOne=new Products(1001,"TV",10000);  
prodOne.getData(); 
var prodTwo=new Products(1002,"CD",1000);
var prodThreee=new Products(1003,"ROBO",5000);