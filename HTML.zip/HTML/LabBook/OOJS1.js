var Products = function(id,name,price){
    var prod={};
    prod.prodId=id;
    prod.prodName=name;
    prod.prodPrice=price;
}; 

var prodOne=Products(1001,"TV",10000);   
var prodTwo=Products(1002,"CD",1000);
var prodThreee=Products(1003,"ROBO",5000);