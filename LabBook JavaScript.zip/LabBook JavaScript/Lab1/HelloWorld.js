function sayHello(){
    var a = document.write("Hello World");
    return a;
}