
        function calculatePayment(){
            var amt = document.getElementById("amount").value;
            var rate = document.getElementById("roi").value;
            var period = document.getElementById("year").value;
            
            var p=parseInt(amt);
            var r=parseInt((rate/1200));
            var t=parseInt(period*12);
            if(p>1500000){
                document.getElementById("error1").innerHTML="Invalid amount";
            }
            else
            {
                if(t<84 || t>180){
                    document.getElementById("error2").innerHTML="Invalid period"
                }
                else
                {
                    var monthlypay=(p*r*Math.pow(1+r,t))/(Math.pow(1+r,t)-1);
                    var totalpay=monthlypay*t;
                    var totalintpay=totalpay-p;
                    document.getElementById("mp").value=monthlypay;
                    document.getElementById("tp").value=totalpay;
                    document.getElementById("ip").value=totalintpay;
                }
            }
        }
 