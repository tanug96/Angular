
    var i=0;
    var id,name,price,k;
    var arrayProduct=[];
    var product = function(id,name,price){
        this.id=id;//prodId is attribute
    this.name=name;
    this.price=price;
    }
    function Myfunction(){
    document.getElementById("show").style.display="block";
    var id=document.getElementById("a").value; 
    var name=document.getElementById("b").value;
    var price=document.getElementById("c").value;
    var pdt = new product(id,name,price);

    arrayProduct.push(pdt);
    document.getElementById("list").innerHTML += "<table><tr><td>ID: "+arrayProduct[i].id+"</td><td>Name: "+arrayProduct[i].name+"</td><td>Price: "+arrayProduct[i].price+"</td></tr></table>";
    i++;
}
function del(r){
    var x = r.parentNode.parentNode.rowIndex;
    arrayProduct.splice(x,1);
    document.getElementById("list").deleteRow(x);
    console.log(x);
}
function upd(r){
    document.getElementById("q").style.display="block";
    document.getElementById("update").innerHTML="<table><tr><td>ID</td><td><input type='text' id='updateid'></td></tr><tr><td>Name</td><td><input type='text' id='updatename'></td></tr><tr><td>Price</td><td><input type='text' id='updateprice'></td></tr></table>"
    k = r.parentNode.parentNode.rowIndex;
    document.getElementById("updateid").value=arrayProduct[k].id;
    document.getElementById("updatename").value=arrayProduct[k].name;
    document.getElementById("updateprice").value=arrayProduct[k].price;
    console.log(k);
}
function updated(){
    console.log(k);
    var newid=document.getElementById("updateid").value;
    var newname=document.getElementById("updatename").value;
    var newprice=document.getElementById("updateprice").value;
    console.log(newid);
    console.log(newname);
    console.log(newprice);
    arrayProduct[k].id=newid;
    arrayProduct[k].name=newname;
    arrayProduct[k].price=newprice;
    console.log(arrayProduct[k]);
    var mytable=document.getElementById("list");
    mytable.rows[k].cells[0].innerHTML=newid;
    mytable.rows[k].cells[1].innerHTML=newname;
    mytable.rows[k].cells[2].innerHTML=newprice;

}

 


