class TV{
    Manufacturer:string
    Size:number
    MaxChannels:number
    Price:number
    DisplayType:string
}