var employee = /** @class */ (function () {
    function employee(FirstName, LastName, Age) {
        this.FirstName = FirstName;
        this.LastName = LastName;
        this.Age = Age;
    }
    employee.prototype.setName = function (FirstName, LastName) {
        this.FirstName = FirstName;
        this.LastName = LastName;
    };
    employee.prototype.getName = function () {
        return this.FirstName + " " + this.LastName;
    };
    employee.prototype.getAge = function () {
        return this.Age;
    };
    return employee;
}());
var e1 = new employee();
