class employee{
    FirstName:string;
    LastName:string;
    Age:number;
    constructor(FirstName:string,LastName:string,Age:number){
        this.FirstName=FirstName;
        this.LastName=LastName;
        this.Age=Age;  
    }

setName(FirstName,LastName){
    this.FirstName=FirstName;
    this.LastName=LastName;
}
getName(){
    return this.FirstName+" "+this.LastName;
}


}
let e1 = new employee();
